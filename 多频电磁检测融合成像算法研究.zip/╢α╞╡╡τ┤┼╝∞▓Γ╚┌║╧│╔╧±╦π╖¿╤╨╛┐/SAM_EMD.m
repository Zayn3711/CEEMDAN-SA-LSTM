function [imf] = SAM_EMD(x, imf_num)
% 简化版经典EMD算法实现
% 输入:
%   x - 输入信号
%   imf_num - 需要分解的IMF数量
% 输出:
%   imf - 分解得到的IMF分量

x = x(:)';
N = length(x);
imf = zeros(imf_num, N);
r = x;

for i = 1:imf_num
    h = r;
    SD = 1;
    iter = 0;
    
    % 筛选过程
    while SD > 0.1 && iter < 10
        % 查找极值点
        [pks_idx, pks_val] = findPeaks(h);
        [val_idx, val_val] = findValleys(h);
        
        % 如果极值点不足，结束此IMF分解
        if length(pks_idx) + length(val_idx) < 3
            break;
        end
        
        % 利用三次样条插值计算上下包络线
        t = 1:N;
        upper_env = computeEnvelope(t, pks_idx, pks_val, N);
        lower_env = computeEnvelope(t, val_idx, val_val, N);
        
        % 计算均值包络
        mean_env = (upper_env + lower_env) / 2;
        
        % 从当前信号中减去均值包络得到新h
        h_prev = h;
        h = h - mean_env;
        
        % 计算筛选终止准则
        SD = sum((h_prev - h).^2) / sum(h_prev.^2 + eps);
        iter = iter + 1;
    end
    
    % 保存当前IMF
    imf(i, :) = h;
    
    % 更新残差
    r = r - h;
    
    % 如果残差很小或只有很少的极值点，终止分解
    if sum(r.^2) < 1e-10 || sum(abs(diff(sign(diff(r))))) < 3
        break;
    end
end

% 如果未能分解足够多的IMF，将剩余行保持为0
if i < imf_num
    imf(i+1:end, :) = 0;
end

end

% 查找信号的峰值
function [locs, vals] = findPeaks(x)
dx = diff(x);
idx = find(diff(sign(dx)) < 0) + 1;
locs = idx;
vals = x(idx);

% 添加边界点(如果是极值)
if x(1) > x(2)
    locs = [1, locs];
    vals = [x(1), vals];
end
if x(end) > x(end-1)
    locs = [locs, length(x)];
    vals = [vals, x(end)];
end
end

% 查找信号的谷值
function [locs, vals] = findValleys(x)
dx = diff(x);
idx = find(diff(sign(dx)) > 0) + 1;
locs = idx;
vals = x(idx);

% 添加边界点(如果是极值)
if x(1) < x(2)
    locs = [1, locs];
    vals = [x(1), vals];
end
if x(end) < x(end-1)
    locs = [locs, length(x)];
    vals = [vals, x(end)];
end
end

% 计算包络线(使用样条插值)
function env = computeEnvelope(t, idx, vals, N)
% 确保有足够的点进行插值
if length(idx) < 2
    if isempty(idx)
        env = zeros(1, N);
    else
        env = ones(1, N) * vals(1);
    end
    return;
end

% 使用三次样条插值计算包络
env = spline(idx, vals, t);
end

