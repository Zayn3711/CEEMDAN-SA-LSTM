clear;clc;close all;

data = load('完整数据.dat');
signal = data(1:1100, 42:end);

inputData = signal;
numTimeStepsTrain = floor(0.8*size(inputData,1));

dataTrain = inputData(1:numTimeStepsTrain,:);
dataTest = inputData(numTimeStepsTrain+1:end,:);

mu = mean(dataTrain);
sig = std(dataTrain);

dataTrainStandardized = (dataTrain - mu) ./ sig;
dataTestStandardized = (dataTest - mu) ./ sig;

XTrain = dataTrainStandardized(1:end-1,:);
YTrain = dataTrainStandardized(2:end,:);
XTest = dataTestStandardized(1:end-1,:);
YTest = dataTestStandardized(2:end,:);

numFeatures = size(XTrain,2);
numResponses = size(YTrain,2);
numHiddenUnits = 100;

XTrain = permute(reshape(XTrain', [numFeatures, 1, size(XTrain,1)]), [1, 3, 2]);
YTrain = permute(reshape(YTrain', [numResponses, 1, size(YTrain,1)]), [1, 3, 2]);
XTest = permute(reshape(XTest', [numFeatures, 1, size(XTest,1)]), [1, 3, 2]);

lstmLayers = [ ...
    sequenceInputLayer(numFeatures)
    lstmLayer(numHiddenUnits)
    fullyConnectedLayer(numResponses)
    regressionLayer];

saLstmLayers = [ ...
    sequenceInputLayer(numFeatures)
    lstmLayer(numHiddenUnits*1.5, 'OutputMode', 'sequence')
    dropoutLayer(0.3)
    bilstmLayer(numHiddenUnits, 'OutputMode', 'sequence')
    fullyConnectedLayer(numHiddenUnits)
    reluLayer
    dropoutLayer(0.2)
    fullyConnectedLayer(numHiddenUnits/2)
    tanhLayer
    fullyConnectedLayer(numResponses)
    regressionLayer];

options = trainingOptions('adam', ...
    'MaxEpochs',500, ...
    'GradientThreshold',1, ...
    'InitialLearnRate',0.005, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',125, ...
    'LearnRateDropFactor',0.2, ...
    'Verbose',0, ...
    'Plots','training-progress');

optionsSALSTM = trainingOptions('adam', ...
    'MaxEpochs',600, ...
    'GradientThreshold',1, ...
    'InitialLearnRate',0.003, ...
    'LearnRateSchedule','piecewise', ...
    'LearnRateDropPeriod',100, ...
    'LearnRateDropFactor',0.1, ...
    'L2Regularization',0.001, ...
    'Verbose',0, ...
    'Shuffle','every-epoch', ...
    'Plots','training-progress');

netLSTM = trainNetwork(XTrain,YTrain,lstmLayers,options);
netSALSTM = trainNetwork(XTrain,YTrain,saLstmLayers,optionsSALSTM);

YPredLSTM = predict(netLSTM,XTest);
YPredLSTM = reshape(YPredLSTM, [numResponses, size(YTest,1)])';
YPredLSTM = YPredLSTM .* sig + mu;

YPredSALSTM = predict(netSALSTM,XTest);
YPredSALSTM = reshape(YPredSALSTM, [numResponses, size(YTest,1)])';
YPredSALSTM = YPredSALSTM .* sig + mu;

YTest = dataTest(2:end,:);

rmseLSTM = sqrt(mean((YPredLSTM-YTest).^2));
rmseSALSTM = sqrt(mean((YPredSALSTM-YTest).^2));

fprintf('LSTM测试集上的均方根误差 (RMSE): %f\n', mean(rmseLSTM));
fprintf('SA-LSTM测试集上的均方根误差 (RMSE): %f\n', mean(rmseSALSTM));

figure
plot(YTest(:,1), 'k-', 'LineWidth', 1.5)
hold on
plot(YPredLSTM(:,1), 'b.-', 'LineWidth', 1)
hold off
legend(["观测值", "LSTM预测值"])
ylabel('特征1')
title('LSTM预测结果')
xlabel('时间步')

figure
plot(YTest(:,1), 'k-', 'LineWidth', 1.5)
hold on
plot(YPredSALSTM(:,1), 'r.-', 'LineWidth', 1)
hold off
legend(["观测值", "SA-LSTM预测值"])
ylabel('特征1')
title('SA-LSTM预测结果')
xlabel('时间步')

figure
stem(1:length(YPredLSTM(:,1)-YTest(:,1)), YPredLSTM(:,1)-YTest(:,1), 'b')
xlabel('时间步')
ylabel('误差')
title('LSTM预测误差')
legend("LSTM误差")

figure
stem(1:length(YPredSALSTM(:,1)-YTest(:,1)), YPredSALSTM(:,1)-YTest(:,1), 'r')
xlabel('时间步')
ylabel('误差')
title('SA-LSTM预测误差')
legend("SA-LSTM误差")

disp('LSTM和SA-LSTM模型训练与测试完成。')
disp(['使用了' num2str(numHiddenUnits) '个隐藏单元。'])
disp(['训练数据集大小: ' num2str(size(dataTrain, 1)) ' 样本'])
disp(['测试数据集大小: ' num2str(size(dataTest, 1)) ' 样本'])
disp(['输入特征数量: ' num2str(numFeatures)])
disp(['LSTM预测误差 (RMSE): ' num2str(mean(rmseLSTM))])
disp(['SA-LSTM预测误差 (RMSE): ' num2str(mean(rmseSALSTM))]) 