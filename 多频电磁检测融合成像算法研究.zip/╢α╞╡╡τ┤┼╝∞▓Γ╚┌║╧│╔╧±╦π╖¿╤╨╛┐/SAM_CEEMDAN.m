function [imf] = SAM_CEEMDAN(x, noise_amp, ensemble_num)
x = x(:)';
N = length(x);
noise_std = std(x);
residue = x;
imf = [];

for i = 1:10 % 最多提取10个IMF
    if i == 1
        % 第一个IMF通过EEMD方式提取
        imf_sum = zeros(1, N);
        
        for j = 1:ensemble_num
            noise = noise_amp * noise_std * randn(1, N);
            temp_imf = SAM_EMD(residue + noise, 1);
            if ~isempty(temp_imf)
                imf_sum = imf_sum + temp_imf(1, :);
            end
        end
        
        current_imf = imf_sum / ensemble_num;
    else
        % 后续IMF通过CEEMDAN方式提取
        modes_sum = zeros(1, N);
        
        for j = 1:ensemble_num
            noise = noise_amp * noise_std * randn(1, N);
            
            % 对噪声进行EMD分解
            noise_imfs = SAM_EMD(noise, i);
            
            if size(noise_imfs, 1) >= i-1
                % 添加适应性噪声
                res_noise = residue + noise_std * noise_imfs(i-1, :) / std(noise_imfs(i-1, :));
                
                % 对残差加噪声进行EMD分解，获取第一个IMF
                temp_modes = SAM_EMD(res_noise, 1);
                if ~isempty(temp_modes)
                    modes_sum = modes_sum + temp_modes(1, :);
                end
            end
        end
        
        current_imf = modes_sum / ensemble_num;
    end
    
    % 保存IMF分量
    imf = [imf; current_imf];
    
    % 更新残差
    residue = residue - current_imf;
    
    % 如果残差很小或几乎是单调的，则停止
    if sum(residue.^2) < 1e-10 || length(findpeaks(residue)) + length(findpeaks(-residue)) < 3
        break;
    end
end

% 添加残差作为最后一个分量
imf = [imf; residue];
end
