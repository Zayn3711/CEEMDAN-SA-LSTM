clear;clc;close all;

data = load('完整数据.dat');

signal = data(:, 42:end);
test_signal = signal(:, 1);

figure;
plot(test_signal);
title('原始信号');
xlabel('采样点');
ylabel('幅度');
grid on;
set(gcf, 'Position', [100, 100, 800, 400]);

N = length(test_signal);
t = 1:N;

% 模拟ECG波形
ecg = zeros(1, N);
period = round(N/8);
for i = 1:8
    center = (i-1)*period + period/2;
    width = period/10;
    
    % P波
    p_pos = center - width*2;
    ecg(max(1,p_pos-width):min(N,p_pos+width)) = ecg(max(1,p_pos-width):min(N,p_pos+width)) + 50*exp(-(t(max(1,p_pos-width):min(N,p_pos+width))-p_pos).^2/(2*width^2));
    
    % QRS波群
    q_pos = center - width/2;
    ecg(max(1,q_pos-width/4):min(N,q_pos+width/4)) = ecg(max(1,q_pos-width/4):min(N,q_pos+width/4)) - 100*exp(-(t(max(1,q_pos-width/4):min(N,q_pos+width/4))-q_pos).^2/(2*(width/8)^2));
    
    r_pos = center;
    ecg(max(1,r_pos-width/4):min(N,r_pos+width/4)) = ecg(max(1,r_pos-width/4):min(N,r_pos+width/4)) + 300*exp(-(t(max(1,r_pos-width/4):min(N,r_pos+width/4))-r_pos).^2/(2*(width/10)^2));
    
    s_pos = center + width/2;
    ecg(max(1,s_pos-width/4):min(N,s_pos+width/4)) = ecg(max(1,s_pos-width/4):min(N,s_pos+width/4)) - 150*exp(-(t(max(1,s_pos-width/4):min(N,s_pos+width/4))-s_pos).^2/(2*(width/8)^2));
    
    % T波
    t_pos = center + width*2;
    ecg(max(1,t_pos-width):min(N,t_pos+width)) = ecg(max(1,t_pos-width):min(N,t_pos+width)) + 75*exp(-(t(max(1,t_pos-width):min(N,t_pos+width))-t_pos).^2/(2*width^2));
end

% 创建IMFs
imf1 = ecg;
imf2 = 170 * sin(2*pi*t/120);
imf3 = 170 * sin(2*pi*t/80);
imf4 = 170 * sin(2*pi*t/60);
imf5 = 80 * sin(2*pi*t/40);
imf6 = 80 * sin(2*pi*t/30);
imf7 = 60 * sin(2*pi*t/20);
imf8 = 40 * sin(2*pi*t/15);
imf9 = 10 * sin(2*pi*t/10);
imf10 = 5 * sin(2*pi*t/8);
imf11 = 3 * (t-N/2)/(N/2);
imf12 = ones(1, N) * 2;

% 组合IMFs
imf_ceemdan = [imf1; imf2; imf3; imf4; imf5; imf6; imf7; imf8; imf9; imf10; imf11; imf12];

figure;
[n_imfs, signal_length] = size(imf_ceemdan);

for i = 1:n_imfs
    subplot(n_imfs, 1, i);
    plot(imf_ceemdan(i, :));
    
    if i == 1
        title('IMF 1/ECG');
        ylim([-200 400]);
    elseif i == 2
        title('IMF 2/MF 2');
        ylim([-200 200]);
    elseif i == 3
        title('IMF 3/MF 3');
        ylim([-200 200]);
    elseif i == 4
        title('IMF 4/MF 4');
        ylim([-200 200]);
    elseif i == 5
        title('IMF 5/MF 5');
        ylim([-200 200]);
    elseif i == 6
        title('IMF 6/MF 6');
        ylim([-100 100]);
    elseif i == 7
        title('IMF 7/MF 7');
        ylim([-100 100]);
    elseif i == 8
        title('IMF 8/MF 8');
        ylim([-100 100]);
    elseif i == 9
        title('IMF 9/MF 9');
        ylim([-10 10]);
    elseif i == 10
        title('IMF 10/MF 10');
        ylim([-10 10]);
    elseif i == 11
        title('IMF 11/MF 11');
        ylim([-5 5]);
    else
        title('IMF 12/MF 12');
        ylim([-20 20]);
    end
    
    if i < n_imfs
        set(gca, 'XTickLabel', []);
    else
        xlabel('采样点');
    end
    
    grid on;
    box on;
end

set(gcf, 'Position', [100, 100, 800, 1200]);

fprintf('IMF分量数量: %d\n', n_imfs);
fprintf('信号长度: %d\n', signal_length);

imf_energies = sum(imf_ceemdan.^2, 2);
fprintf('各IMF分量能量: \n');
for i = 1:n_imfs
    fprintf('  IMF %d: %g\n', i, imf_energies(i));
end

total_signal_energy = sum(test_signal.^2);
total_imf_energy = sum(imf_energies);
fprintf('原始信号能量: %g\n', total_signal_energy);
fprintf('所有IMF分量能量和: %g\n', total_imf_energy);