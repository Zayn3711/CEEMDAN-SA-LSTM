function [imf] = SAM_CEEMD(x, noise_amp, ensemble_num)
% 互补集合经验模态分解 (CEEMD)
% 输入:
%   x - 输入信号
%   noise_amp - 噪声幅度
%   ensemble_num - 集合平均次数
% 输出:
%   imf - 分解得到的IMF分量

x = x(:)';
N = length(x);
noise_std = std(x);

% 初始化正噪声和负噪声的IMF总和
imf_pos_total = [];
imf_neg_total = [];

% 对每个集合进行处理
for i = 1:ensemble_num
    % 生成随机噪声
    noise = noise_amp * noise_std * randn(1, N);
    
    % 正噪声分量
    noisy_signal_pos = x + noise;
    temp_imf_pos = SAM_EMD(noisy_signal_pos, 10);
    
    % 负噪声分量
    noisy_signal_neg = x - noise;
    temp_imf_neg = SAM_EMD(noisy_signal_neg, 10);
    
    % 累加IMF
    if isempty(imf_pos_total)
        imf_pos_total = temp_imf_pos;
        imf_neg_total = temp_imf_neg;
    else
        min_rows_pos = min(size(imf_pos_total, 1), size(temp_imf_pos, 1));
        min_rows_neg = min(size(imf_neg_total, 1), size(temp_imf_neg, 1));
        
        imf_pos_total(1:min_rows_pos, :) = imf_pos_total(1:min_rows_pos, :) + temp_imf_pos(1:min_rows_pos, :);
        imf_neg_total(1:min_rows_neg, :) = imf_neg_total(1:min_rows_neg, :) + temp_imf_neg(1:min_rows_neg, :);
    end
end

% 计算最终IMF（正负噪声平均值）
[rows_pos, ~] = size(imf_pos_total);
[rows_neg, ~] = size(imf_neg_total);
max_rows = max(rows_pos, rows_neg);

% 扩展矩阵大小以匹配
if rows_pos < max_rows
    imf_pos_total(rows_pos+1:max_rows, :) = 0;
end
if rows_neg < max_rows
    imf_neg_total(rows_neg+1:max_rows, :) = 0;
end

% 计算CEEMD结果
imf = (imf_pos_total + imf_neg_total) / (2 * ensemble_num);
end
